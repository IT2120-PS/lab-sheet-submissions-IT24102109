setwd("C://Users//IT24102109//Desktop//IT24102109 Lab 6")
getwd()

##n=50, p=0.85
##Q1.i.
##binomial distribution

##Q1.ii.
1-pbinom(46, 50, 0.85, lower.tail=TRUE)

##Q2.i.
##number of calls per hour

##Q2.ii.
##poisson distribution

##Q2.iii.
dpois(15, 12)
