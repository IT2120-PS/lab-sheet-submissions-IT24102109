setwd("C://Users//HP//Desktop//IT24102109 Lab 5")
getwd()

##Q1
Delivery_Times<-read.table("Exercise - Lab 05.txt", header=TRUE)

fix(Delivery_Times)

attach(Delivery_Times)

##Q2
histogram<-hist(Delivery_Time_.minutes.,main = "Histogram for the Deliver Times",xlab="Intervals",breaks = seq(20,70,length=10),right=FALSE)

##Q4
##Class limits of the distribution are entered to the histogram
breaks<-histogram$breaks

##Frequencies are entered to the variable 'freq'
freq<-histogram$counts

##identify the midpoints of each class
mids<-histogram$mids

##calculate cumulative frequencies
cum.freq<-cumsum(freq)

##store the cumulative frequencies to build an ogive
new<-c()

for (i in 1:length(breaks)) {
  if(i==1){
    new[i]=0
  }else{
    new[i]=cum.freq[i-1]
  }
}

##Draw ogive
plot(breaks, new, type='l',main="Cumulative Frequency Polygon for Delivery Times",xlab = "Classes",ylab="Cumulative Frequencies", ylim = c(0,max(cum.freq)))