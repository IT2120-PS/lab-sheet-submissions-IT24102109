setwd("C://Users/HP/Desktop/IT24102109 Lab 8")
getwd()

data<-read.table("Exercise - LaptopsWeights.txt", header=TRUE)

fix(data)

attach(data)

##Q1

##std = standard deviation
popmean<-mean(Weight.kg.)
popmean
popvar<-var(Weight.kg.)
popstd<-sqrt(popvar)
popstd


##Q2
samples<-c()
n<-c()

for(i in 1:25){
  s<-sample(Weight.kg.,6,replace=TRUE)
  samples<-cbind(samples,s)
  n<-c(n,paste('S',i))
}

colnames(samples) = n

fix(samples)

sample.means<-apply(samples,2,mean)
sample.var<-apply(samples,2,var)

print("sample mean for each sample")
sample.means

sample.sd<-sqrt(sample.var)
print("sample standard deviation for each sample")
sample.sd

##Q3
samplemeans.mean<-mean(sample.means)
samplemeans.sd<-sd(sample.means)

abs(popmean-samplemeans.mean) < 0.01

abs(samplemeans.sd-popstd/sqrt(6)) < 0.1


